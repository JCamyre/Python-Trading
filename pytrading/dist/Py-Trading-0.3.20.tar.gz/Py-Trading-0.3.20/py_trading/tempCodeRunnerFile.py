            # for article in googlenews.result():
            #     sector_news.append(article.get_texts(), article.get_links())
            # sector_news.append([ i for i in zip(googlenews.get_texts(), googlenews.get_links())])
            