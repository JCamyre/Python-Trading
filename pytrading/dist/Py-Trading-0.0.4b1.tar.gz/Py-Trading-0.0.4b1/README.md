# Pytrading
This package contains modules with functions that assist day and swing traders by aiding them in keeping track of their positions 
and trending stocks.
