    # df['ticker'] = df['ticker'].unique()
    # df['name'] = df['name'].unique()