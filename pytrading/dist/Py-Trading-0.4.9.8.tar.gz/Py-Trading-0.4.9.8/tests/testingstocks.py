import py_trading as pytrd 

print(pytrd.Stock('TSLA').due_diligence())
